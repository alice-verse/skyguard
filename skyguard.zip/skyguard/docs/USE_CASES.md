# Use cases

Seven worked scenarios. The output blocks are the actual output of `node examples/use_cases.mjs` (simulated data, seed 11), saved in `docs/use_case_output.txt`.

Each reading is judged against a model trained on 14 days of simulated history for one station with three simulated neighbours.

## 1. The example from the problem statement: 55 C, very humid, pressure drop, neighbours normal

**Situation.** A station reports 55 °C, 97% humidity and a sharp pressure drop while its neighbours report ordinary weather. This is the example given in the problem statement.

**What a good checker should do.** The reading should be rejected, explained, and replaced with a sensible estimate, and the next normal reading should confirm it was a one-off.

**What SkyGuard does.** Several independent checks agree: the dew point would be 54 °C, the changes are far beyond the limits, and neighbours disagree. The root cause is reported as physically inconsistent readings. When the next reading returns to normal, the earlier record is confirmed as a spike.

```text
Suspect reading
  Reading: T=55 P=992.3 RH=97  (2026-05-16T01:00:00.000Z)
  Alert (critical, 100% confidence): Physically inconsistent temperature and humidity
  - 13% of the evidence: temperature is 58.5 sigma above its usual value for this hour
  - 13% of the evidence: pressure is 20.6 sigma below its usual value for this hour
  - 13% of the evidence: 55°C with 97% humidity gives a 54°C dew point, which is not physically plausible
  - 13% of the evidence: temperature changed by +35.5°C in one step (limit 6.0°C)
  - 13% of the evidence: pressure changed by -14.1 hPa in one step (limit 3.0 hPa)
  - 12% of the evidence: temperature is +35.4°C from neighbouring stations (tolerance 4°C)
  - 12% of the evidence: pressure is -14.4 hPa from neighbouring stations (tolerance 3 hPa)
  - 12% of the evidence: Temperature, pressure and humidity changed together in a way rarely seen in history (distance 24655, limit 25)
  - Suggested replacement: temperature about 18.6, pressure about 1006.4, humidity about 92.8

Next reading
  Reading: T=19.3 P=1006.4 RH=88.2  (2026-05-16T01:10:00.000Z)
  No alert (confidence 0%)
  - Earlier record #150: temperature jump confirmed as a spike
  - Earlier record #150: pressure jump confirmed as a spike
```

## 2. Spike: temperature jumps +25 C for one reading, then returns

**Situation.** One temperature reading jumps by 25 °C and the next reading is normal again.

**What a good checker should do.** Flag it at once, and learn from the next reading that it was a spike rather than a real change.

**What SkyGuard does.** It is flagged immediately as a sudden jump with a suggested replacement. When the next reading returns to normal, the earlier record is re-labelled as a spike. Note that in real use the first alert cannot know yet whether the jump will persist.

```text
Spike reading
  Reading: T=44.1 P=1006.3 RH=90  (2026-05-16T01:00:00.000Z)
  Alert (critical, 100% confidence): Physically inconsistent temperature and humidity
  - 26% of the evidence: temperature is 40.3 sigma above its usual value for this hour
  - 25% of the evidence: 44.1°C with 90% humidity gives a 42°C dew point, which is not physically plausible
  - 25% of the evidence: temperature changed by +24.6°C in one step (limit 6.0°C)
  - 24% of the evidence: Temperature, pressure and humidity changed together in a way rarely seen in history (distance 7352, limit 25)
  - Suggested replacement: temperature about 18.6, humidity about 92.8

Next reading
  Reading: T=19.3 P=1006.4 RH=88.2  (2026-05-16T01:10:00.000Z)
  No alert (confidence 0%)
  - Earlier record #150: temperature jump confirmed as a spike
```

## 3. Frozen sensor: temperature stuck at 22.0 for 20 readings

**Situation.** A temperature sensor locks onto 22.0 and never changes.

**What a good checker should do.** Detect it without raising an alarm on a few repeated values, which happen naturally.

**What SkyGuard does.** Seventeen identical readings pass. The eighteenth (three hours at 10 minutes) is flagged as a frozen sensor, with medium severity that rises the longer it continues. The delay is the price of avoiding false alarms. Saturated humidity at 100% is exempt, because fog and rain can hold it there.

```text
Reading 17 (not yet flagged as frozen)
  Reading: T=22 P=1006.6 RH=87.3  (2026-05-16T03:40:00.000Z)
  No alert (confidence 4%)
  - 100% of the evidence: temperature is 4.3 sigma above its usual value for this hour

Reading 18 (flagged)
  Reading: T=22 P=1006.8 RH=86.9  (2026-05-16T03:50:00.000Z)
  Alert (medium, 62% confidence): Frozen sensor: value not changing
  - 93% of the evidence: temperature has not changed for 18 samples (22°C)
  - 7% of the evidence: temperature is 4.3 sigma above its usual value for this hour
  - Suggested replacement: temperature about 22
```

## 4. Genuine weather vs sensor fault: the same sudden 7 C drop, with and without neighbours

**Situation.** The same sudden 7 °C temperature drop appears in two situations. In one, neighbouring stations see the same drop. In the other, they do not.

**What a good checker should do.** A real weather event (such as storm outflow) must not raise an alert; the same change on one station alone should.

**What SkyGuard does.** With neighbours agreeing, the change is recorded as 'not counted' and no alert is raised. With neighbours calm, the same reading is flagged as critical. This is the main way SkyGuard separates real weather from sensor faults, and it needs neighbouring stations. Without them the detector cannot make this distinction.

```text
Neighbours report the same drop (real weather)
  Reading: T=12.1 P=1006.3 RH=99  (2026-05-16T01:00:00.000Z)
  No alert (confidence 20%)
  - 100% of the evidence: temperature is 13.0 sigma below its usual value for this hour
  - Not counted: temperature changed by -7.4°C, but neighbouring stations changed by -7.2°C: treated as a real weather event
  - Not counted: Unusual combined change, but neighbouring stations changed the same way

Neighbours report nothing unusual (suspect sensor)
  Reading: T=12.1 P=1006.3 RH=99  (2026-05-16T01:00:00.000Z)
  Alert (critical, 100% confidence): Sudden jump (awaiting confirmation)
  - 28% of the evidence: temperature is 13.0 sigma below its usual value for this hour
  - 26% of the evidence: temperature is -7.5°C from neighbouring stations (tolerance 4°C)
  - 26% of the evidence: Temperature, pressure and humidity changed together in a way rarely seen in history (distance 568, limit 25)
  - 19% of the evidence: temperature changed by -7.4°C in one step (limit 6.0°C)
  - Suggested replacement: temperature about 18.6
```

## 5. Communication failure: placeholder value -999 for pressure

**Situation.** The logger sends -999 for pressure because the sensor link failed.

**What a good checker should do.** Recognise a placeholder value as missing data, not as a real reading, and never let it distort later checks.

**What SkyGuard does.** It is flagged as a communication error rather than a physical-range violation, and a replacement estimate is suggested.

```text
Placeholder reading
  Reading: T=19.1 P=-999 RH=90  (2026-05-16T01:00:00.000Z)
  Alert (critical, 95% confidence): Communication error: missing or placeholder value
  - 100% of the evidence: pressure is missing or a placeholder value (-999)
  - Suggested replacement: pressure about 1006.4
```

## 6. Calibration drift: temperature sensor creeps up 0.02 C per reading (+4 C total)

**Situation.** A temperature sensor creeps upward by 0.02 °C per reading, reaching +4 °C after 200 readings.

**What a good checker should do.** Notice a slow offset that no single reading reveals, and recommend maintenance.

**What SkyGuard does.** After one day nothing is flagged: the offset is still small. By 400 readings the sensor is on Watch with maintenance recommended and a drift message naming only temperature. Drift is judged against neighbouring stations when available, because a slow weather system would otherwise look like drift. Without neighbours, that confusion is possible.

```text
After 144 readings: status Healthy, maintenance recommended: false
  - flagged readings in last day: 0%

After 400 readings: status Watch, maintenance recommended: true
  - 2.1% of the last 144 readings were flagged
  - temperature has been reading above expectations for a long time (2.69 sigma): possible calibration drift
  - flagged readings in last day: 2%
```

## 7. Timing problems: missing records and a repeated record

**Situation.** Records go missing for 50 minutes, and later the same record is sent twice.

**What a good checker should do.** Report timing problems separately from bad values.

**What SkyGuard does.** The missing records are reported as a communication gap and the repeat as a duplicate timestamp. The change across the gap is deliberately not judged as a single-step jump.

```text
Records 150 to 154 never arrived
  Reading: T=18.3 P=1006.1 RH=88.2  (2026-05-16T01:50:00.000Z)
  Alert (critical, 90% confidence): Communication gap: observations missing
  - 100% of the evidence: 5 observation(s) missing before this record

The same record sent twice
  Reading: T=18.3 P=1006.1 RH=88.2  (2026-05-16T01:50:00.000Z)
  Alert (critical, 90% confidence): Data corruption: duplicate timestamp
  - 100% of the evidence: Same timestamp as the previous record
```

## Limits shared by all use cases

- Everything here is simulated. Real stations are messier.
- Thresholds are assumptions in `src/config.js`.
- Corrected values are estimates from the daily pattern, not measurements.
