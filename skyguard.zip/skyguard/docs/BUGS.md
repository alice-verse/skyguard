# Defect log

Defects found while building and testing SkyGuard, using the standard fields: severity, how it was found, status. SG-001 to SG-004 each have a regression test that was checked to fail without the fix and pass with it. SG-005 is a methodology fix with no automated test.

| ID | Summary | Severity | Status |
|---|---|---|---|
| SG-001 | Root cause hid the real cause | Medium | Fixed |
| SG-002 | Floating-point error flagged a change of exactly the limit | Medium | Fixed |
| SG-003 | Slow weather system reported as pressure drift | High | Fixed (with a remaining limit) |
| SG-004 | Gap in the record caused a false multivariate alert | Medium | Fixed |
| SG-005 | First evaluation was too easy to be meaningful | High | Fixed |
| SG-006 | Real weather events sometimes alerted on noisy data | Medium | Open |
| SG-007 | Dashboard never opened in a real browser | Medium | Open |

## SG-001 Root cause hid the real cause
- **Found by:** running the 55 °C example from the problem statement.
- **Expected:** root cause "physically inconsistent temperature and humidity".
- **Actual:** "Unusual for this time of day", because that generic check scored highest.
- **Cause:** root cause was chosen by highest score, and the generic check saturates at 1.0 for huge deviations.
- **Fix:** choose the most specific strong check first; the generic one only wins when nothing else fired.
- **Test:** `55 C with 97% humidity is physically implausible`.

## SG-002 Floating-point error flagged a change of exactly the limit
- **Found by:** writing a boundary test (limit, limit plus 0.1).
- **Steps:** reading 26.2 °C then 32.2 °C with a 6 °C limit.
- **Expected:** accepted, since the change is exactly 6.0.
- **Actual:** flagged, because `32.2 - 26.2` is `6.0000000000000036` in floating point.
- **Fix:** round the difference to 6 decimal places before comparing.
- **Test:** `regression: floating-point noise must not turn a change of exactly 6.0 into 6.000000000000004`.

## SG-003 Slow weather system reported as pressure drift
- **Found by:** the calibration-drift use case. Only temperature was drifted, but the health panel also blamed pressure after one day.
- **Cause:** drift was judged against the station's own hourly pattern, and a slow pressure system stays above that pattern for a day.
- **Fix:** when neighbouring stations are available, drift is measured against them, since real weather moves every station.
- **Remaining limit:** without neighbours the old behaviour applies, so drift can still be confused with weather.
- **Test:** `a slow calibration offset is reported as drift` (checks the one-day mark and that only temperature is blamed).

## SG-004 Gap in the record caused a false multivariate alert
- **Found by:** reading the output of the timing use case.
- **Actual:** after five missing records, the change across the 50-minute gap was judged as a single 10-minute step.
- **Fix:** time lost to a gap now counts when scaling jump limits and disables the one-step joint-change check.
- **Test:** `the change across a communication gap is not judged as a one-step change`.

## SG-005 First evaluation was too easy to be meaningful
- **Found by:** noticing 100% recall everywhere, including on deliberately subtle faults.
- **Cause:** the simulator's sensor noise was so small that any blip stood out.
- **Fix:** added a sensor-noise setting, subtle faults, and five random seeds. The README now reports both quiet and noisy results.

## SG-006 Real weather events sometimes alerted on noisy data (open)
- **Steps:** `npm run evaluate`, noisy-sensor table, seed 3.
- **Actual:** 2 of 4 genuine weather events produced alerts.
- **Notes:** neighbour confirmation uses fixed agreement tolerances that are tight when sensors are noisy. Candidate fix: scale tolerances by each station's measured noise.

## SG-007 Dashboard never opened in a real browser (open)
- **Notes:** the dashboard logic was run against a stubbed page, but layout and canvas drawing have not been checked in Chrome, Firefox or on a phone. Next step: Playwright tests plus manual check.
