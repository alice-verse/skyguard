import { mergeConfig } from './config.js';
import {
  clamp, mean, median, madSigma, dewPointC, invert3, quadForm, covariance3,
} from './stats.js';

export const VARS = ['temperature', 'pressure', 'humidity'];
const UNIT = { temperature: '°C', pressure: ' hPa', humidity: '%' };

// When two checks score the same, the earlier one in this list is reported as the root cause.
const PRIORITY = [
  'range', 'missing', 'invalid_timestamp', 'duplicate_timestamp', 'out_of_order',
  'physical_dewpoint', 'flatline', 'spike', 'level_shift', 'jump',
  'spatial_inconsistency', 'multivariate_step', 'communication_gap', 'seasonal_residual',
];

const CAUSE = {
  range: 'Sensor fault: value outside physical range',
  missing: 'Communication error: missing or placeholder value',
  invalid_timestamp: 'Data corruption: unreadable timestamp',
  duplicate_timestamp: 'Data corruption: duplicate timestamp',
  out_of_order: 'Data corruption: timestamps out of order',
  physical_dewpoint: 'Physically inconsistent temperature and humidity',
  flatline: 'Frozen sensor: value not changing',
  spike: 'Spike: sudden jump that reverted',
  level_shift: 'Level shift: sensor jumped and stayed at a new level',
  jump: 'Sudden jump (awaiting confirmation)',
  spatial_inconsistency: 'Disagrees with neighbouring stations',
  multivariate_step: 'Inconsistent change across temperature, pressure and humidity',
  communication_gap: 'Communication gap: observations missing',
  seasonal_residual: 'Unusual for this time of day',
};

export const toMs = (t) => {
  if (typeof t === 'number') return t;
  if (t instanceof Date) return t.getTime();
  return typeof t === 'string' ? Date.parse(t) : NaN;
};

const isNum = (x) => typeof x === 'number' && Number.isFinite(x);

function severityOf(confidence, alertAt) {
  if (confidence >= 0.9) return 'critical';
  if (confidence >= 0.75) return 'high';
  if (confidence >= alertAt) return 'medium';
  return 'none';
}

/* ------------------------------------------------------------------ */
/* Model: learns what "normal" looks like from historical data         */
/* ------------------------------------------------------------------ */
export class SkyGuardModel {
  constructor(config = {}) {
    this.cfg = mergeConfig(config);
    this.baseline = null; // typical value and spread for each hour of the day
    this.stepInv = null; // learned relationship between simultaneous changes
    this.trainedOn = 0;
  }

  isUsable(o) {
    return VARS.every((v) => {
      const x = o[v];
      if (!isNum(x) || this.cfg.missingSentinels.includes(x)) return false;
      return x >= this.cfg.range[v][0] && x <= this.cfg.range[v][1];
    });
  }

  fit(history) {
    const cfg = this.cfg;
    const rows = history.filter((o) => this.isUsable(o) && Number.isFinite(toMs(o.t)));
    this.trainedOn = rows.length;
    if (rows.length < 48) return this; // not enough history; checks that need it are skipped

    const hours = Array.from({ length: 24 }, () => ({ temperature: [], pressure: [], humidity: [] }));
    const all = { temperature: [], pressure: [], humidity: [] };
    for (const o of rows) {
      const h = new Date(toMs(o.t)).getUTCHours();
      for (const v of VARS) { hours[h][v].push(o[v]); all[v].push(o[v]); }
    }
    const global = {};
    for (const v of VARS) {
      const med = median(all[v]);
      global[v] = { median: med, sigma: Math.max(madSigma(all[v], med), cfg.sigmaFloor[v]) };
    }
    this.baseline = {
      hours: hours.map((h) => {
        const out = {};
        for (const v of VARS) {
          if (h[v].length < 5) { out[v] = global[v]; continue; }
          const med = median(h[v]);
          out[v] = { median: med, sigma: Math.max(madSigma(h[v], med), cfg.sigmaFloor[v]) };
        }
        return out;
      }),
    };

    // Learn how temperature, pressure and humidity normally change together.
    const iv = cfg.intervalMinutes * 60000;
    const steps = [];
    for (let i = 1; i < rows.length; i++) {
      const dt = toMs(rows[i].t) - toMs(rows[i - 1].t);
      if (dt > 0.5 * iv && dt < 1.5 * iv) steps.push(VARS.map((v) => rows[i][v] - rows[i - 1][v]));
    }
    if (steps.length >= 30) {
      const med = [0, 1, 2].map((j) => median(steps.map((s) => s[j])));
      const sig = [0, 1, 2].map((j) => Math.max(madSigma(steps.map((s) => s[j]), med[j]), 1e-3));
      // Clip extreme steps so faults in the history cannot distort the model.
      const clipped = steps.map((s) => s.map((x, j) => clamp(x, med[j] - 6 * sig[j], med[j] + 6 * sig[j])));
      const { cov } = covariance3(clipped);
      for (let i = 0; i < 3; i++) cov[i][i] *= 1.02;
      this.stepInv = invert3(cov);
    }
    return this;
  }

  expected(v, hour) {
    return this.baseline && hour !== null ? this.baseline.hours[hour][v] : null;
  }
}

/* ------------------------------------------------------------------ */
/* Stream: checks each new observation as it arrives                   */
/* ------------------------------------------------------------------ */
export class SkyGuardStream {
  constructor(model, { stationId = 'AWS-1' } = {}) {
    this.model = model;
    this.cfg = model.cfg;
    this.stationId = stationId;
    this.results = [];
    this.prevMs = null;
    this.last = {}; // last trusted value per variable
    this.since = {};
    this.run = {};
    this.lastVal = {};
    this.pending = {};
    this.resid = {};
    this.zHist = {};
    for (const v of VARS) {
      this.since[v] = 0; this.run[v] = 0; this.pending[v] = []; this.resid[v] = []; this.zHist[v] = [];
    }
  }

  _finalize(r) {
    r.confidence = +(1 - r.checks.reduce((p, c) => p * (1 - c.score), 1)).toFixed(3);
    r.flagged = r.confidence >= this.cfg.alertConfidence;
    r.severity = r.flagged ? severityOf(r.confidence, this.cfg.alertConfidence) : 'none';
    // The root cause is the most specific strong check. "Unusual for this time of
    // day" only wins when nothing more specific fired.
    const strongChecks = r.checks.filter((c) => c.score >= 0.5);
    const pool = strongChecks.length ? strongChecks : r.checks;
    const top = [...pool].sort(
      (a, b) => PRIORITY.indexOf(a.rule) - PRIORITY.indexOf(b.rule) || b.score - a.score,
    )[0];
    r.rootCause = r.flagged && top ? CAUSE[top.rule] : null;
    r.variablesAffected = [...new Set(r.checks.filter((c) => c.score >= 0.5).map((c) => c.variable))];
  }

  _reclassify(idx, v, rule, score, message, revises) {
    const r = this.results[idx];
    const c = r && r.checks.find((x) => x.rule === 'jump' && x.variable === v);
    if (!c) return;
    c.rule = rule; c.score = score; c.message = message;
    this._finalize(r);
    revises.push({ index: idx, variable: v, rule, rootCause: r.rootCause, confidence: r.confidence });
  }

  ingest(obs, neighbors = null) {
    const cfg = this.cfg;
    const index = this.results.length;
    const ms = toMs(obs.t);
    const checks = [];
    const suppressed = [];
    const revises = [];
    const add = (rule, variable, score, message) => {
      if (score > 0) checks.push({ rule, variable, score: +score.toFixed(3), message });
    };

    // 1. Timestamp checks
    let missedSamples = 0;
    if (!Number.isFinite(ms)) {
      add('invalid_timestamp', 'time', 0.9, 'Timestamp is missing or unreadable');
    } else if (this.prevMs !== null) {
      const dt = ms - this.prevMs;
      const iv = cfg.intervalMinutes * 60000;
      if (dt === 0) add('duplicate_timestamp', 'time', 0.9, 'Same timestamp as the previous record');
      else if (dt < 0) add('out_of_order', 'time', 0.8, 'Timestamp is earlier than the previous record');
      else if (dt > 1.5 * iv) {
        const missed = Math.round(dt / iv) - 1;
        missedSamples = missed;
        add('communication_gap', 'time', clamp(0.5 + 0.1 * missed, 0.5, 0.9),
          `${missed} observation(s) missing before this record`);
      }
    }
    if (Number.isFinite(ms) && (this.prevMs === null || ms > this.prevMs)) this.prevMs = ms;
    const hour = Number.isFinite(ms) ? new Date(ms).getUTCHours() : null;

    // 2. Neighbouring stations (optional): median of what they report right now
    const nm = {};
    if (neighbors && neighbors.length >= 2) {
      for (const v of VARS) {
        const vals = neighbors.map((n) => n && n[v]).filter(
          (x) => isNum(x) && !cfg.missingSentinels.includes(x) && x >= cfg.range[v][0] && x <= cfg.range[v][1],
        );
        if (vals.length >= 2) nm[v] = median(vals);
      }
    }
    const hasN = (v) => nm[v] !== undefined;
    const prev = { ...this.last };

    // 3. Per-variable checks
    const val = {}, ok = {}, strong = {}, zs = {}, step = {};
    let confirmedAny = false;
    for (const v of VARS) {
      const x = obs[v];
      this.since[v] += 1 + missedSamples; // time passed during a gap counts
      ok[v] = false; strong[v] = false; zs[v] = null;

      if (!isNum(x) || cfg.missingSentinels.includes(x)) {
        add('missing', v, 0.95, `${v} is missing or a placeholder value (${x})`);
        this.run[v] = 0; strong[v] = true;
        continue;
      }
      val[v] = x;
      const [lo, hi] = cfg.range[v];
      if (x < lo || x > hi) {
        add('range', v, 1, `${v} ${x}${UNIT[v]} is outside the physical range ${lo} to ${hi}`);
        this.run[v] = 0; strong[v] = true;
        continue;
      }
      ok[v] = true;

      // Frozen value
      this.run[v] = this.lastVal[v] === x ? this.run[v] + 1 : 1;
      this.lastVal[v] = x;
      const need = cfg.flatlineSamples[v];
      if (this.run[v] >= need && !(v === 'humidity' && x >= cfg.flatlineExemptHumidity)) {
        add('flatline', v, clamp(0.6 + (0.4 * (this.run[v] - need)) / need, 0.6, 0.98),
          `${v} has not changed for ${this.run[v]} samples (${x}${UNIT[v]})`);
        strong[v] = true;
      }

      // Sudden jump compared with the last trusted value
      const lg = prev[v];
      if (lg) {
        const limit = cfg.maxStep[v] * Math.max(1, Math.sqrt(this.since[v]));
        // Round away floating-point noise so a change of exactly the limit is accepted.
        const d = Math.round((x - lg.v) * 1e6) / 1e6;
        step[v] = d;
        if (Math.abs(d) > limit) {
          const nStep = hasN(v) && lg.nm !== undefined ? nm[v] - lg.nm : null;
          if (nStep !== null && Math.abs(d - nStep) <= cfg.neighborStepAgree[v]) {
            confirmedAny = true;
            this.pending[v] = [];
            suppressed.push(`${v} changed by ${d.toFixed(1)}${UNIT[v]}, but neighbouring stations changed by ${nStep.toFixed(1)}${UNIT[v]}: treated as a real weather event`);
          } else {
            const pend = this.pending[v];
            pend.push({ index, v: x });
            const span = Math.max(...pend.map((p) => p.v)) - Math.min(...pend.map((p) => p.v));
            if (pend.length >= cfg.sustainedJumpSamples && span <= cfg.maxStep[v]) {
              add('level_shift', v, 0.9, `${v} stayed near ${x}${UNIT[v]} for ${pend.length} samples after a ${d.toFixed(1)}${UNIT[v]} jump`);
              for (const p of pend.slice(0, -1)) {
                this._reclassify(p.index, v, 'level_shift', 0.9, `${v} jumped and stayed at the new level`, revises);
              }
              this.last[v] = { v: x, nm: nm[v] };
              this.since[v] = 0;
              this.pending[v] = [];
            } else {
              add('jump', v, clamp(0.6 + 0.4 * (Math.abs(d) / limit - 1), 0.6, 0.98),
                `${v} changed by ${d > 0 ? '+' : ''}${d.toFixed(1)}${UNIT[v]} in one step (limit ${limit.toFixed(1)}${UNIT[v]})`);
            }
            strong[v] = true;
          }
        } else if (this.pending[v].length) {
          // The value came back: the earlier jump was a spike.
          for (const p of this.pending[v]) {
            this._reclassify(p.index, v, 'spike', 0.98, `${v} jumped and returned to normal on the next sample`, revises);
          }
          this.pending[v] = [];
        }
      }

      // Distance from the learned hourly pattern
      const b = this.model.expected(v, hour);
      if (b) {
        const z = (x - b.median) / b.sigma;
        zs[v] = z;
        const s = clamp((Math.abs(z) - cfg.residualZ.start) / (cfg.residualZ.full - cfg.residualZ.start), 0, 1);
        if (s > 0) add('seasonal_residual', v, s, `${v} is ${Math.abs(z).toFixed(1)} sigma ${z > 0 ? 'above' : 'below'} its usual value for this hour`);
      }

      // Disagreement with neighbours
      if (hasN(v)) {
        const dev = x - nm[v];
        const tol = cfg.spatialTol[v];
        if (Math.abs(dev) > tol) {
          add('spatial_inconsistency', v, clamp(0.6 + 0.4 * (Math.abs(dev) / tol - 1), 0.6, 0.95),
            `${v} is ${dev > 0 ? '+' : ''}${dev.toFixed(1)}${UNIT[v]} from neighbouring stations (tolerance ${tol}${UNIT[v]})`);
          strong[v] = true;
        }
      }
    }

    // 4. Do the three readings make sense together?
    let agreeAll = false;
    let genuineMulti = false;
    if (VARS.every((v) => ok[v] && prev[v] && this.since[v] === 1) && this.model.stepInv) {
      const sv = VARS.map((v) => obs[v] - prev[v].v);
      const d2 = quadForm(sv, this.model.stepInv);
      agreeAll = VARS.every((v) => hasN(v) && prev[v].nm !== undefined
        && Math.abs(sv[VARS.indexOf(v)] - (nm[v] - prev[v].nm)) <= cfg.neighborStepAgree[v]);
      if (d2 > cfg.mahalanobis.start) {
        if (agreeAll) {
          genuineMulti = true;
          suppressed.push('Unusual combined change, but neighbouring stations changed the same way');
        } else {
          const { start, full } = cfg.mahalanobis;
          add('multivariate_step', 'multiple', clamp(0.5 + (0.5 * (d2 - start)) / (full - start), 0.5, 0.95),
            `Temperature, pressure and humidity changed together in a way rarely seen in history (distance ${d2.toFixed(0)}, limit ${start})`);
        }
      }
    }
    if (agreeAll) {
      for (const c of checks) if (c.rule === 'seasonal_residual') c.score = +(c.score * 0.2).toFixed(3);
    }

    // 5. Physics check: how humid can air at this temperature really be?
    if (ok.temperature && ok.humidity) {
      const td = dewPointC(obs.temperature, obs.humidity);
      if (td > cfg.dewpointMaxC) {
        const blame = zs.temperature !== null && zs.humidity !== null && Math.abs(zs.humidity) > Math.abs(zs.temperature)
          ? 'humidity' : 'temperature';
        add('physical_dewpoint', blame, clamp(0.7 + (td - cfg.dewpointMaxC) / 20, 0.7, 0.99),
          `${obs.temperature}°C with ${obs.humidity}% humidity gives a ${td.toFixed(0)}°C dew point, which is not physically plausible`);
        strong.temperature = true; strong.humidity = true;
      }
    }

    const result = {
      index,
      t: Number.isFinite(ms) ? new Date(ms).toISOString() : String(obs.t),
      values: { temperature: obs.temperature, pressure: obs.pressure, humidity: obs.humidity },
      checks, suppressed, revises,
      genuineEvent: confirmedAny || genuineMulti,
      corrected: null,
    };
    this._finalize(result);

    // 6. Suggested replacement values for readings we do not trust
    if (result.flagged) {
      const est = {};
      for (const v of VARS) {
        if (!strong[v]) continue;
        const b = this.model.expected(v, hour);
        const offset = this.resid[v].length ? mean(this.resid[v]) : 0;
        const e = b ? b.median + offset : prev[v] ? prev[v].v : null;
        if (e !== null) est[v] = +e.toFixed(1);
      }
      if (Object.keys(est).length) result.corrected = est;
    }

    // 7. Update what we trust
    for (const v of VARS) {
      if (!ok[v] || strong[v]) continue;
      this.last[v] = { v: val[v], nm: nm[v] };
      this.since[v] = 0;
      const b = this.model.expected(v, hour);
      if (b) {
        this.resid[v].push(val[v] - b.median);
        if (this.resid[v].length > 3) this.resid[v].shift();
        // Judge drift against neighbours when we have them: real weather moves every
        // station together, a drifting sensor does not.
        const dz = hasN(v) ? (val[v] - nm[v]) / (cfg.spatialTol[v] / 3) : (val[v] - b.median) / b.sigma;
        this.zHist[v].push(dz);
        if (this.zHist[v].length > cfg.health.window) this.zHist[v].shift();
      }
    }

    this.results.push(result);
    return result;
  }

  // Sensor health over the most recent window
  health() {
    const h = this.cfg.health;
    const recent = this.results.slice(-h.window);
    const n = recent.length;
    const flagged = recent.filter((r) => r.flagged);
    const rate = n ? flagged.length / n : 0;
    const perVariable = { temperature: 0, pressure: 0, humidity: 0 };
    for (const r of flagged) for (const v of r.variablesAffected) if (v in perVariable) perVariable[v] += 1;

    let status = 'Healthy';
    const reasons = [];
    if (rate >= h.degradedRate) { status = 'Degraded'; reasons.push(`${(rate * 100).toFixed(1)}% of the last ${n} readings were flagged`); }
    else if (rate >= h.watchRate) { status = 'Watch'; reasons.push(`${(rate * 100).toFixed(1)}% of the last ${n} readings were flagged`); }

    const drift = {};
    let driftFound = false;
    for (const v of VARS) {
      const zh = this.zHist[v];
      drift[v] = zh.length ? +mean(zh).toFixed(2) : 0;
      if (zh.length >= h.window / 2 && Math.abs(drift[v]) > h.driftZ) {
        driftFound = true;
        reasons.push(`${v} has been reading ${drift[v] > 0 ? 'above' : 'below'} expectations for a long time (${drift[v]} sigma): possible calibration drift`);
      }
    }
    if (driftFound && status === 'Healthy') status = 'Watch';
    return {
      status, samples: n, anomalyRate: +rate.toFixed(4), perVariable, drift, reasons,
      maintenanceRecommended: status === 'Degraded' || driftFound,
    };
  }
}

// Convenience: run a whole list of observations through a fresh stream.
export function analyze(model, observations, neighborsAt = () => null) {
  const stream = new SkyGuardStream(model);
  const results = observations.map((o) => stream.ingest(o, neighborsAt(toMs(o.t))));
  return { results, health: stream.health() };
}

// Plain-language explanation: how much each piece of evidence contributed.
// This is a transparent rule breakdown, not SHAP or LIME.
export function explain(r) {
  const head = r.flagged
    ? `Alert (${r.severity}, ${Math.round(r.confidence * 100)}% confidence): ${r.rootCause}`
    : `No alert (confidence ${Math.round(r.confidence * 100)}%)`;
  const total = r.checks.reduce((s, c) => s + c.score, 0);
  const lines = [...r.checks]
    .sort((a, b) => b.score - a.score)
    .map((c) => `  - ${Math.round((100 * c.score) / total)}% of the evidence: ${c.message}`);
  const extra = r.suppressed.map((s) => `  - Not counted: ${s}`);
  const fix = r.corrected
    ? [`  - Suggested replacement: ${Object.entries(r.corrected).map(([k, x]) => `${k} about ${x}`).join(', ')}`]
    : [];
  return [head, ...lines, ...extra, ...fix].join('\n');
}
