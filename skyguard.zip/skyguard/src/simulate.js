// Synthetic weather generator. Everything is seeded, so results are reproducible.
// This is simulated data: results measured on it say nothing about real stations.

export function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const gauss = (rng) => {
  let u = 0;
  while (!u) u = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rng());
};
const r1 = (x) => Math.round(x * 10) / 10;
const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));

// One target station plus neighbours that share the same weather.
export function generateStations({
  days = 28, seed = 42, intervalMinutes = 10, neighbors = 3, start = '2026-05-01T00:00:00Z', noise = 1,
} = {}) {
  const rng = mulberry32(seed);
  const iv = intervalMinutes * 60000;
  const n = Math.round((days * 24 * 60) / intervalMinutes);
  const t0 = Date.parse(start);

  // Slow, shared weather variation (identical for every station).
  const syn = { T: [], P: [], H: [] };
  let sT = 0, sP = 0, sH = 0;
  for (let i = 0; i < n; i++) {
    sT = 0.995 * sT + 0.08 * gauss(rng);
    sP = 0.998 * sP + 0.07 * gauss(rng);
    sH = 0.99 * sH + 0.8 * gauss(rng);
    syn.T.push(sT); syn.P.push(sP); syn.H.push(sH);
  }

  const stations = [];
  for (let s = 0; s <= neighbors; s++) {
    const offT = (rng() - 0.5) * 0.8;
    const offP = (rng() - 0.5) * 0.6;
    const offH = (rng() - 0.5) * 4;
    const obs = [];
    for (let i = 0; i < n; i++) {
      const ts = t0 + i * iv;
      const h = (ts % 86400000) / 3600000;
      const T = 27 + 7 * Math.sin((2 * Math.PI * (h - 9)) / 24) + syn.T[i] + offT + 0.15 * noise * gauss(rng);
      const P = 1005 + 0.8 * Math.sin((4 * Math.PI * (h - 4)) / 24) + syn.P[i] + offP + 0.08 * noise * gauss(rng);
      const H = clamp(65 - 2.4 * (T - 27) + syn.H[i] + offH + 0.8 * noise * gauss(rng), 5, 100);
      obs.push({ t: new Date(ts).toISOString(), temperature: r1(T), pressure: r1(P), humidity: r1(H) });
    }
    stations.push(obs);
  }
  return stations;
}

// Real weather affects every station, so the same change is applied to all of them.
function applyGenuine(stations, type, idx) {
  const shape = type === 'front'
    ? Array.from({ length: 36 }, (_, k) => (k < 12 ? (k + 1) / 12 : 1 - (k - 11) / 24))
    : [1, 0.85, 0.7, 0.5, 0.3, 0.15]; // outflow: sudden change, quick recovery
  const amp = type === 'front'
    ? { temperature: -8, pressure: -6, humidity: 25 }
    : { temperature: -7, pressure: 2, humidity: 20 };
  for (const st of stations) {
    shape.forEach((w, k) => {
      const o = st[idx + k];
      if (!o) return;
      o.temperature = r1(o.temperature + amp.temperature * w);
      o.pressure = r1(o.pressure + amp.pressure * w);
      o.humidity = r1(clamp(o.humidity + amp.humidity * w, 5, 100));
    });
  }
  return shape.length;
}

export const FAULT_PLAN = [
  ['spike', 6], ['frozen', 3], ['dropout', 4], ['out_of_range', 4], ['inconsistent', 3],
  ['duplicate', 3], ['gap', 3], ['subtle', 4], ['front', 2], ['outflow', 2],
];

export function generateScenario({
  trainDays = 14, testDays = 14, seed = 42, intervalMinutes = 10, inject = true, noise = 1,
} = {}) {
  const perDay = (24 * 60) / intervalMinutes;
  const iv = intervalMinutes * 60000;
  const stations = generateStations({ days: trainDays + testDays, seed, intervalMinutes, noise });
  const split = trainDays * perDay;
  const train = stations[0].slice(0, split);
  const test = stations.map((s) => s.slice(split).map((o) => ({ ...o })));
  const rng = mulberry32(seed + 1);
  const faultEvents = [];
  const genuineEvents = [];
  const ms = (i) => Date.parse(test[0][i].t);

  let faulty = test[0].map((o) => ({ ...o }));
  if (inject) {
    const jobs = FAULT_PLAN.flatMap(([type, count]) => Array.from({ length: count }, () => type));
    for (let i = jobs.length - 1; i > 0; i--) { // seeded shuffle
      const j = Math.floor(rng() * (i + 1));
      [jobs[i], jobs[j]] = [jobs[j], jobs[i]];
    }
    const warmup = 200;
    const slot = Math.floor((test[0].length - warmup - 40) / jobs.length);
    const inserts = [];
    const deletes = [];
    const pick = (arr) => arr[Math.floor(rng() * arr.length)];
    const sign = () => (rng() < 0.5 ? -1 : 1);

    // Genuine events first, because they change the neighbours too.
    jobs.forEach((type, k) => {
      if (type !== 'front' && type !== 'outflow') return;
      const idx = warmup + k * slot + Math.floor(rng() * (slot - 40));
      const len = applyGenuine(test, type, idx);
      genuineEvents.push({ type, t0: ms(idx), t1: ms(Math.min(idx + len - 1, test[0].length - 1)) });
    });
    faulty = test[0].map((o) => ({ ...o }));

    jobs.forEach((type, k) => {
      if (type === 'front' || type === 'outflow') return;
      const idx = warmup + k * slot + Math.floor(rng() * (slot - 40));
      const o = faulty[idx];
      const t = ms(idx);
      const v = pick(['temperature', 'pressure', 'humidity']);
      if (type === 'spike') {
        if (v === 'temperature') o.temperature = r1(o.temperature + sign() * (15 + rng() * 15));
        else if (v === 'pressure') o.pressure = r1(o.pressure + sign() * (8 + rng() * 7));
        else o.humidity = r1(o.humidity > 50 ? o.humidity - 40 : o.humidity + 40);
        faultEvents.push({ type, variable: v, t0: t, t1: t });
      } else if (type === 'frozen') {
        const len = 24 + Math.floor(rng() * 7);
        const hold = o[v];
        for (let q = 0; q < len; q++) faulty[idx + q][v] = hold;
        faultEvents.push({ type, variable: v, t0: t, t1: ms(idx + len - 1) });
      } else if (type === 'subtle') {
        // Deliberately small errors, below the step and neighbour limits.
        if (v === 'temperature') o.temperature = r1(o.temperature + sign() * (3 + rng() * 1.5));
        else if (v === 'pressure') o.pressure = r1(o.pressure + sign() * (1.8 + rng() * 0.8));
        else o.humidity = r1(clamp(o.humidity + sign() * (18 + rng() * 6), 5, 100));
        faultEvents.push({ type, variable: v, t0: t, t1: t });
      } else if (type === 'dropout') {
        const bad = rng() < 0.5 ? null : -999;
        faulty[idx][v] = bad;
        faultEvents.push({ type, variable: v, t0: t, t1: t });
      } else if (type === 'out_of_range') {
        if (v === 'temperature') o.temperature = pick([85, -80]);
        else if (v === 'pressure') o.pressure = pick([50, 1500]);
        else o.humidity = pick([130, -5]);
        faultEvents.push({ type, variable: v, t0: t, t1: t });
      } else if (type === 'inconsistent') {
        o.temperature = 55; o.humidity = 98; o.pressure = r1(o.pressure - 14);
        faultEvents.push({ type, variable: 'multiple', t0: t, t1: t });
      } else if (type === 'duplicate') {
        inserts.push(idx);
        faultEvents.push({ type, variable: 'time', t0: t, t1: t });
      } else if (type === 'gap') {
        deletes.push(idx + 1);
        faultEvents.push({ type, variable: 'time', t0: ms(idx + 6), t1: ms(idx + 6) });
      }
    });

    // Structural edits last, from the end backwards so earlier indexes stay valid.
    const edits = [
      ...inserts.map((i) => ({ i, kind: 'dup' })),
      ...deletes.map((i) => ({ i, kind: 'gap' })),
    ].sort((a, b) => b.i - a.i);
    for (const e of edits) {
      if (e.kind === 'dup') faulty.splice(e.i + 1, 0, { ...faulty[e.i] });
      else faulty.splice(e.i, 5);
    }
  }

  const byTime = new Map();
  test.slice(1).forEach((st) => st.forEach((o) => {
    const k = Date.parse(o.t);
    if (!byTime.has(k)) byTime.set(k, []);
    byTime.get(k).push(o);
  }));

  return {
    intervalMs: iv, train, test: faulty, cleanTest: test[0], faultEvents, genuineEvents,
    neighborsAt: (t) => byTime.get(t) || null,
  };
}
