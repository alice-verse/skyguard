import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { parseCsv, toCsv } from './csv.js';
import { SkyGuardModel, analyze, explain } from './detector.js';
import { evaluate, evaluateSeeds, runExample55 } from './evaluate.js';
import { generateScenario } from './simulate.js';

const [cmd = 'help', ...args] = process.argv.slice(2);

function printEvaluation(m) {
  console.log(`Simulated test period: ${m.samples} samples, ${m.faultEvents} injected fault events, ${m.genuineEvents} genuine weather events\n`);
  console.log('Fault type          events  detected  recall');
  for (const [type, s] of Object.entries(m.byType)) {
    console.log(`${type.padEnd(18)}  ${String(s.events).padStart(6)}  ${String(s.detected).padStart(8)}  ${s.recall.toFixed(2)}`);
  }
  console.log(`\nOverall event recall:            ${m.detectedEvents}/${m.faultEvents} (${(m.eventRecall * 100).toFixed(0)}%)`);
  console.log(`Alert precision:                 ${m.alertPrecision === null ? 'n/a' : (m.alertPrecision * 100).toFixed(0) + '%'} of ${m.totalAlerts} alerts were on injected faults`);
  console.log(`False alarms on clean data:      ${m.falseAlarmsOnCleanData} of ${m.cleanSamples} samples (${(m.falseAlarmRate * 100).toFixed(2)}%)`);
  console.log(`Genuine events wrongly alerted:  ${m.genuineEventsWronglyAlerted} of ${m.genuineEvents}`);
  console.log(`Frozen-sensor detection delay:   ${m.frozenLatencySamples} samples after the freeze began`);
  for (const noise of [1, 4]) {
    console.log(`\nFive random seeds, sensor noise x${noise}${noise > 1 ? ' (noisier, harder)' : ''}:`);
    console.log('seed  event recall  false-alarm rate  genuine events wrongly alerted  subtle-fault recall');
    for (const r of evaluateSeeds([42, 1, 2, 3, 4], undefined, noise)) {
      console.log(`${String(r.seed).padStart(4)}  ${r.eventRecall.toFixed(2).padStart(12)}  ${(r.falseAlarmRate * 100).toFixed(2).padStart(15)}%  ${String(r.genuineWronglyAlerted).padStart(30)}  ${String(r.subtleRecall).padStart(19)}`);
    }
  }
  console.log('\nThese numbers come from simulated data with known faults. They do not predict performance on real stations.');
}

function demo() {
  console.log('=== Example use case: station suddenly reports 55 C, 97% humidity, pressure drop; neighbours normal ===\n');
  const { out, health } = runExample55();
  out.forEach(({ input, result }, i) => {
    const label = ['Previous reading', 'Suspect reading', 'Next reading'][i];
    console.log(`${label} (${result.t}): T=${input.temperature} P=${input.pressure} RH=${input.humidity}`);
    console.log(explain(result));
    for (const r of result.revises) console.log(`  - Earlier record #${r.index}: ${r.variable} ${r.rule === 'spike' ? 'jump confirmed as a spike (it returned to normal)' : 'jump confirmed as a level shift'}`);
    console.log('');
  });
  console.log(`Sensor health: ${health.status}\n`);
  console.log('=== Evaluation on simulated faults ===\n');
  printEvaluation(evaluate());
}

function detect(file) {
  const rows = parseCsv(readFileSync(file, 'utf8'));
  const model = new SkyGuardModel().fit(rows);
  const { results, health } = analyze(model, rows);
  const flagged = results.filter((r) => r.flagged);
  console.log(`${rows.length} readings, ${flagged.length} flagged (no neighbour data in a single CSV)\n`);
  for (const r of flagged.slice(0, 40)) {
    console.log(`#${r.index} ${r.t}  ${r.severity}  ${r.rootCause}  (${r.variablesAffected.join(', ')})`);
  }
  if (flagged.length > 40) console.log(`... and ${flagged.length - 40} more`);
  console.log(`\nSensor health: ${health.status}${health.reasons.length ? ' - ' + health.reasons.join('; ') : ''}`);
  console.log(`Maintenance recommended: ${health.maintenanceRecommended ? 'yes' : 'no'}`);
}

function generateSample() {
  const scn = generateScenario();
  const rows = [...scn.train, ...scn.test];
  mkdirSync('data', { recursive: true });
  writeFileSync('data/sample.csv', toCsv(rows));
  console.log(`Wrote data/sample.csv (${rows.length} rows, ${scn.faultEvents.length} injected faults in the second half)`);
}

if (cmd === 'demo') demo();
else if (cmd === 'evaluate') printEvaluation(evaluate());
else if (cmd === 'detect') detect(args[0] || 'data/sample.csv');
else if (cmd === 'generate-sample') generateSample();
else {
  console.log('Usage: node src/cli.js <demo | evaluate | detect <file.csv> | generate-sample>');
}

