import { generateScenario } from './simulate.js';
import { SkyGuardModel, SkyGuardStream, toMs } from './detector.js';

// Runs the detector over a simulated scenario whose faults are known, and
// counts what it caught. Faults are judged per event (a frozen sensor lasting
// 30 samples is one event) and false alarms per clean sample.
export function evaluate({ scenario, config } = {}) {
  const scn = scenario || generateScenario();
  const model = new SkyGuardModel(config).fit(scn.train);
  const stream = new SkyGuardStream(model);
  const results = scn.test.map((o) => stream.ingest(o, scn.neighborsAt(toMs(o.t))));
  const iv = scn.intervalMs;

  const inWindow = (t, events) => events.some((e) => t >= e.t0 - iv && t <= e.t1 + iv);
  const byType = {};
  const latencies = [];
  for (const e of scn.faultEvents) {
    const hits = results.filter((r) => r.flagged && toMs(r.t) >= e.t0 && toMs(r.t) <= e.t1 + iv);
    const slot = (byType[e.type] ||= { events: 0, detected: 0 });
    slot.events += 1;
    if (hits.length) {
      slot.detected += 1;
      if (e.type === 'frozen') latencies.push(Math.round((toMs(hits[0].t) - e.t0) / iv));
    }
  }
  for (const s of Object.values(byType)) s.recall = +(s.detected / s.events).toFixed(3);

  const totalEvents = scn.faultEvents.length;
  const detected = Object.values(byType).reduce((s, x) => s + x.detected, 0);

  let cleanSamples = 0, falseAlarmsClean = 0, alertsInFaults = 0, alertsInGenuine = 0, totalAlerts = 0;
  for (const r of results) {
    const t = toMs(r.t);
    const inFault = inWindow(t, scn.faultEvents);
    const inGenuine = inWindow(t, scn.genuineEvents);
    if (r.flagged) {
      totalAlerts += 1;
      if (inFault) alertsInFaults += 1;
      else if (inGenuine) alertsInGenuine += 1;
    }
    if (!inFault && !inGenuine) { cleanSamples += 1; if (r.flagged) falseAlarmsClean += 1; }
  }
  const genuineAlerted = scn.genuineEvents.filter((e) =>
    results.some((r) => r.flagged && toMs(r.t) >= e.t0 - iv && toMs(r.t) <= e.t1 + iv)).length;

  return {
    samples: results.length,
    faultEvents: totalEvents,
    detectedEvents: detected,
    eventRecall: +(detected / totalEvents).toFixed(3),
    byType,
    frozenLatencySamples: latencies.length ? +(latencies.reduce((a, b) => a + b, 0) / latencies.length).toFixed(1) : null,
    totalAlerts,
    alertPrecision: totalAlerts ? +(alertsInFaults / totalAlerts).toFixed(3) : null,
    cleanSamples,
    falseAlarmsOnCleanData: falseAlarmsClean,
    falseAlarmRate: +(falseAlarmsClean / cleanSamples).toFixed(4),
    genuineEvents: scn.genuineEvents.length,
    genuineEventsWronglyAlerted: genuineAlerted,
    alertsDuringGenuineEvents: alertsInGenuine,
    health: stream.health(),
    results,
    scenario: scn,
  };
}

// The worked example from the problem statement: an AWS suddenly reports 55 C,
// very high humidity and an abnormal pressure change while neighbours look normal.
export function runExample55({ seed = 7 } = {}) {
  const scn = generateScenario({ trainDays: 14, testDays: 3, seed, inject: false });
  const model = new SkyGuardModel().fit(scn.train);
  const stream = new SkyGuardStream(model);
  const clean = scn.test;
  const at = 150;
  const out = [];
  for (let i = 0; i < at + 2; i++) {
    let o = clean[i];
    if (i === at) o = { ...o, temperature: 55, humidity: 97, pressure: +(o.pressure - 14).toFixed(1) };
    const r = stream.ingest(o, scn.neighborsAt(toMs(o.t)));
    // Snapshot now: later readings may re-label earlier ones.
    if (i >= at - 1) out.push({ input: o, result: JSON.parse(JSON.stringify(r)) });
  }
  return { out, health: stream.health() };
}

// Same evaluation on several random seeds, to show how much the numbers move.
export function evaluateSeeds(seeds = [42, 1, 2, 3, 4], config, noise = 1) {
  return seeds.map((seed) => {
    const m = evaluate({ scenario: generateScenario({ seed, noise }), config });
    return {
      seed, eventRecall: m.eventRecall, falseAlarmRate: m.falseAlarmRate,
      genuineWronglyAlerted: m.genuineEventsWronglyAlerted, subtleRecall: m.byType.subtle?.recall ?? null,
    };
  });
}
