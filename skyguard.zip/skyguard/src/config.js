// All thresholds are ASSUMPTIONS chosen for a 10-minute observation interval.
// They are starting points, not official meteorological limits. Tune them per
// network, altitude and climate (see README "Limitations").

export const DEFAULTS = {
  intervalMinutes: 10,

  // Values that data loggers commonly send when a sensor or link fails.
  missingSentinels: [-999, -9999, 9999, 99999],

  // Physical limits (inclusive). Pressure is station pressure, so the lower
  // bound is generous to allow high-altitude stations.
  range: {
    temperature: [-60, 60],
    pressure: [400, 1100],
    humidity: [0, 100],
  },

  // Largest believable change between two consecutive samples.
  maxStep: { temperature: 6, pressure: 3, humidity: 30 },

  // Identical consecutive values needed before a sensor is called "frozen"
  // (18 samples = 3 hours at 10 minutes).
  flatlineSamples: { temperature: 18, pressure: 18, humidity: 18 },
  // Saturated air (fog, rain) can legitimately sit at 100% for hours.
  flatlineExemptHumidity: 99.5,

  // Smallest spread used when learning the daily pattern, so quiet history
  // does not make the detector over-sensitive.
  sigmaFloor: { temperature: 0.6, pressure: 0.4, humidity: 3 },

  // Distance from the learned hourly pattern, in robust standard deviations.
  // Score is 0 at `start` and 1 at `full`.
  residualZ: { start: 4, full: 10 },

  // Mahalanobis distance squared of the (dT, dP, dRH) change vector.
  mahalanobis: { start: 25, full: 60 },

  // A dew point above this is treated as physically implausible (degrees C).
  dewpointMaxC: 35,

  // Disagreement with the median of neighbouring stations.
  spatialTol: { temperature: 4, pressure: 3, humidity: 25 },
  // How closely a station's change must match its neighbours' change for the
  // change to count as a genuine weather event.
  neighborStepAgree: { temperature: 3, pressure: 1.5, humidity: 15 },

  alertConfidence: 0.5,

  // A jump that persists this many samples at a stable new level is reported
  // as a level shift instead of a spike.
  sustainedJumpSamples: 3,

  health: {
    window: 144, // 24 hours at 10 minutes
    driftZ: 2.5, // mean distance from the usual pattern, in sigmas
    watchRate: 0.02,
    degradedRate: 0.08,
  },
};

export function mergeConfig(overrides = {}) {
  const out = {};
  for (const [key, value] of Object.entries(DEFAULTS)) {
    const o = overrides[key];
    out[key] =
      value && typeof value === 'object' && !Array.isArray(value)
        ? { ...value, ...(o || {}) }
        : o !== undefined
          ? o
          : value;
  }
  return out;
}
