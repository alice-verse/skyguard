export const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));

export function mean(arr) {
  return arr.length ? arr.reduce((s, x) => s + x, 0) / arr.length : NaN;
}

export function median(arr) {
  if (!arr.length) return NaN;
  const s = [...arr].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

// Robust standard deviation estimate: unaffected by a few bad readings.
export function madSigma(arr, med = median(arr)) {
  return 1.4826 * median(arr.map((x) => Math.abs(x - med)));
}

// Dew point in degrees C from air temperature (C) and relative humidity (%),
// using the Magnus formula.
export function dewPointC(tC, rh) {
  const a = 17.62;
  const b = 243.12;
  const g = Math.log(Math.max(rh, 1) / 100) + (a * tC) / (b + tC);
  return (b * g) / (a - g);
}

export function covariance3(rows) {
  const n = rows.length;
  const mu = [0, 1, 2].map((j) => mean(rows.map((r) => r[j])));
  const cov = [0, 1, 2].map(() => [0, 0, 0]);
  for (const r of rows) {
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) cov[i][j] += (r[i] - mu[i]) * (r[j] - mu[j]);
    }
  }
  return { mu, cov: cov.map((row) => row.map((x) => x / Math.max(1, n - 1))) };
}

export function invert3(m) {
  const [a, b, c] = m[0];
  const [d, e, f] = m[1];
  const [g, h, i] = m[2];
  const A = e * i - f * h;
  const B = -(d * i - f * g);
  const C = d * h - e * g;
  const det = a * A + b * B + c * C;
  if (Math.abs(det) < 1e-12) return null;
  return [
    [A / det, -(b * i - c * h) / det, (b * f - c * e) / det],
    [B / det, (a * i - c * g) / det, -(a * f - c * d) / det],
    [C / det, -(a * h - b * g) / det, (a * e - b * d) / det],
  ];
}

export function quadForm(v, M) {
  let s = 0;
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) s += v[i] * M[i][j] * v[j];
  return s;
}
