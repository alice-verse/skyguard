// Columns: timestamp,temperature,pressure,humidity (a few common aliases are accepted).
const ALIASES = {
  t: ['timestamp', 'time', 'datetime', 'date', 't'],
  temperature: ['temperature', 'temp', 'temperature_c', 'temp_c'],
  pressure: ['pressure', 'pressure_hpa', 'press', 'pres'],
  humidity: ['humidity', 'rh', 'relative_humidity', 'humidity_pct'],
};

export function parseCsv(text) {
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter((l) => l.trim() !== '');
  if (lines.length < 2) throw new Error('CSV needs a header row and at least one data row');
  const header = lines[0].split(',').map((h) => h.trim().toLowerCase());
  const col = {};
  for (const [key, names] of Object.entries(ALIASES)) {
    col[key] = header.findIndex((h) => names.includes(h));
    if (col[key] === -1) throw new Error(`Missing column "${key}". Found: ${header.join(', ')}`);
  }
  return lines.slice(1).map((line) => {
    const cells = line.split(',').map((c) => c.trim());
    const num = (i) => {
      const raw = cells[i];
      if (raw === undefined || raw === '' || raw.toLowerCase() === 'null' || raw.toLowerCase() === 'nan') return null;
      const n = Number(raw);
      return Number.isFinite(n) ? n : null;
    };
    return {
      t: cells[col.t],
      temperature: num(col.temperature),
      pressure: num(col.pressure),
      humidity: num(col.humidity),
    };
  });
}

export function toCsv(observations) {
  const cell = (x) => (x === null || x === undefined ? '' : x);
  const rows = observations.map((o) => [o.t, cell(o.temperature), cell(o.pressure), cell(o.humidity)].join(','));
  return ['timestamp,temperature,pressure,humidity', ...rows].join('\n') + '\n';
}
