// Runs seven worked use cases and prints what SkyGuard says about each.
// Usage: node examples/use_cases.mjs
import { SkyGuardModel, SkyGuardStream, explain, toMs } from '../src/detector.js';
import { generateScenario } from '../src/simulate.js';

const scn = generateScenario({ trainDays: 14, testDays: 3, seed: 11, inject: false });
const model = new SkyGuardModel().fit(scn.train);
const at = (i) => scn.test[i];
const nb = (i) => scn.neighborsAt(toMs(at(i).t));

function warm(n = 150) {
  const st = new SkyGuardStream(model);
  for (let i = 0; i < n; i++) st.ingest(at(i), nb(i));
  return st;
}
const show = (title, obs, r) => {
  console.log(`${title}`);
  console.log(`  Reading: T=${obs.temperature} P=${obs.pressure} RH=${obs.humidity}  (${r.t})`);
  console.log(explain(r).split('\n').map((l) => (l.startsWith('  ') ? l : '  ' + l)).join('\n'));
  for (const v of r.revises) console.log(`  - Earlier record #${v.index}: ${v.variable} jump confirmed as ${v.rule === 'spike' ? 'a spike' : 'a level shift'}`);
  console.log('');
};
const heading = (s) => console.log(`\n${'='.repeat(70)}\n${s}\n${'='.repeat(70)}\n`);

heading('1. The example from the problem statement: 55 C, very humid, pressure drop, neighbours normal');
{
  const st = warm();
  const bad = { ...at(150), temperature: 55, humidity: 97, pressure: +(at(150).pressure - 14).toFixed(1) };
  show('Suspect reading', bad, st.ingest(bad, nb(150)));
  show('Next reading', at(151), st.ingest(at(151), nb(151)));
}

heading('2. Spike: temperature jumps +25 C for one reading, then returns');
{
  const st = warm();
  const bad = { ...at(150), temperature: +(at(150).temperature + 25).toFixed(1) };
  show('Spike reading', bad, st.ingest(bad));
  show('Next reading', at(151), st.ingest(at(151)));
}

heading('3. Frozen sensor: temperature stuck at 22.0 for 20 readings');
{
  const st = warm();
  for (let k = 0; k < 20; k++) {
    const o = { ...at(150 + k), temperature: 22.0 };
    const r = st.ingest(o);
    if (k === 16) show('Reading 17 (not yet flagged as frozen)', o, r);
    if (k === 17) show('Reading 18 (flagged)', o, r);
  }
}

heading('4. Genuine weather vs sensor fault: the same sudden 7 C drop, with and without neighbours');
{
  const change = (o) => ({ ...o, temperature: +(o.temperature - 7).toFixed(1), humidity: Math.min(99, +(o.humidity + 20).toFixed(1)) });
  const drop = change(at(150));
  show('Neighbours report the same drop (real weather)', drop, warm().ingest(drop, nb(150).map(change)));
  show('Neighbours report nothing unusual (suspect sensor)', drop, warm().ingest(drop, nb(150)));
}

heading('5. Communication failure: placeholder value -999 for pressure');
{
  const bad = { ...at(150), pressure: -999 };
  show('Placeholder reading', bad, warm().ingest(bad, nb(150)));
}

heading('6. Calibration drift: temperature sensor creeps up 0.02 C per reading (+4 C total)');
{
  const st = new SkyGuardStream(model);
  for (let i = 0; i < 400; i++) {
    const drift = Math.min(i * 0.02, 4);
    st.ingest({ ...at(i), temperature: +(at(i).temperature + drift).toFixed(1) }, nb(i));
    if (i === 143 || i === 399) {
      const h = st.health();
      console.log(`After ${i + 1} readings: status ${h.status}, maintenance recommended: ${h.maintenanceRecommended}`);
      h.reasons.forEach((x) => console.log(`  - ${x}`));
      console.log(`  - flagged readings in last day: ${Math.round(h.anomalyRate * 100)}%\n`);
    }
  }
}

heading('7. Timing problems: missing records and a repeated record');
{
  const st = warm();
  show('Records 150 to 154 never arrived', at(155), st.ingest(at(155), nb(155)));
  show('The same record sent twice', at(155), st.ingest(at(155), nb(155)));
}
